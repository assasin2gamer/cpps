import React, { useState, useEffect } from "react";


import {Link} from 'react-router-dom'



import { BrowserRouter, Routes, Route} from 'react-router-dom'
import { CssBaseline } from '@mui/material';
import Commerce from '@chec/commerce.js';

import './styles/scss/styles.scss';

import Cart from "./components/Cart/Cart"
import Checkout from "./components/CheckoutForm/Checkout/Checkout"
import  Navbar from "../NavBar/Navbar.js";
import Products from "./components/Products/Products";

function square(){
    
}  
const commerce = new Commerce("pk_443954304ed80924c5b6eacfb7438c27952d8da408049", true);

export {commerce}



const Product = () => {
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({});

  const fetchProducts = async () => {
    const { data } = await commerce.products.list({
      limit: 100,
    });

    setProducts(data);
  };

  const fetchCart = async () => {
    setCart(await commerce.cart.retrieve());
  };

  const handleAddToCart = async (productId, quantity) => {
    const item = await commerce.cart.add(productId, quantity);

    setCart(item.cart);
  };




  useEffect(() => {
    fetchProducts();
    fetchCart();
  }, []);

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);

/*<Route exact path="/cart">
            <Cart cart={cart} onUpdateCartQty={handleUpdateCartQty} onRemoveFromCart={handleRemoveFromCart} onEmptyCart={handleEmptyCart} />
          </Route>
          <Route path="/checkout" exact>
            <Checkout cart={cart} order={order} onCaptureCheckout={handleCaptureCheckout} error={errorMessage} />
          </Route> */
  let tag = "all"

  var base_link = window.location.origin;


  return (
    <div style = {{display:'flex'}}>
  
      
      <div style={{width:'100px', paddingRight:'10px'}}>
        <a style={{width:'50px', paddingRight:'10px'}} href={base_link+'/menu/?product=sushi'}><button>Sushi</button></a>
        <a style={{width:'50px', paddingRight:'10px'}} href={base_link+'/menu/?product=dishes'}><button>Dishes</button></a>
        <a style={{width:'50px', paddingRight:'10px'}} href={base_link+'/menu/?product=korean'}><button>Korean</button></a>
        <a style={{width:'50px', paddingRight:'10px'}} href={base_link+'/cart'}><button>Cart</button></a>

      </div>
     

      <div style={{width:'100%'}}>
            <Products products={products} onAddToCart={handleAddToCart} qry = {tag} handleUpdateCartQty />
      </div>
    </div>
  )
};



export default Product;