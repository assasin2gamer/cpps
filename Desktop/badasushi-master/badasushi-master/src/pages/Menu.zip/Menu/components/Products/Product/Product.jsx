import React from 'react';
import { Card, CardMedia, CardContent, CardActions, Typography, IconButton } from '@mui/material';
import { AddShoppingCart } from '@mui/icons-material';


const Product = ({ product, onAddToCart }) => {



  const handleAddToCart = () => onAddToCart(product.id, 1);
  



    return (
      <Card style ={{}}>
        <img style={{ height:'200px', objectFit:'contain'}} src={product.image.url} alt={product.name} />
        <CardContent style= {{height:'100px'}}>
          <div >
            <Typography gutterBottom variant="h5" component="h2">
              {product.name}
            </Typography>
            <Typography gutterBottom variant="h5" component="h2">
              ${product.price.formatted}
            </Typography>
          </div>
          {/*<Typography dangerouslySetInnerHTML={{ __html: product.description }} variant="body2" color="textSecondary" component="p" />*/}
        </CardContent>
        <CardActions>
          <IconButton aria-label="Add to Cart" onClick={handleAddToCart}>
            <AddShoppingCart />
          </IconButton>
        </CardActions>
      </Card>
    );
    
  
  

  
};

export default Product;

