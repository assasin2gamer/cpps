import React from 'react';
import Grid from '@mui/material/Grid';

import Product from './Product/Product';

const Products = ({ products, onAddToCart, tag }) => {
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const url_tag = urlParams.get('product')

  const checker = (product) => {
  
    let product2 = JSON.stringify(product)
    
    product2 = JSON.parse(product2)
    product2 = product2['description']
    product2 = product2.slice(3)
    product2 = product2.slice(0, -4)
    product2 = JSON.parse(product2)
    
  
    let product_tag = null
  
    try{
      product_tag = product2['tag']
      if (product_tag == url_tag){
        return(
          <Grid style={{top:""}} key={product.id} item xs={12} sm={1} md={4} lg={3}>
                <Product product={product} onAddToCart={onAddToCart} />
              </Grid>
        )
      }
      
    }
    catch{
      return null
    }

    

  }

  if (!products.length) return <p>Loading...</p>;

  return (
    <main >
      <div  />
      <Grid style = {{position:'absolute', width:'80%', top:'100px'}} container justify="center" spacing={2}>
      
        {products.map((product) => checker(product))}
      
      </Grid>
    </main>
  );
};

export default Products;

